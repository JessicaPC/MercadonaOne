package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }
    
    final String agedBlueCheese = "Aged blue cheese";
    final String ham = "Ham";
    final String iodizedSalt = "Iodized salt";
    final String bread = "Bread";
    final String yogurt = "Yogurt";
    final String frozenCake = "Frozen cake";
    
    final int maxQuality = 50;
    final int minQuality = 0;
    
    public void updateQuality() {
    	
    	for(Item item : items) {
    		if(!item.name.equals(iodizedSalt)) {
	    		if(item.name.equals(agedBlueCheese)) {
	    			if(item.quality < maxQuality) {
	    				item.quality+=1;
	    			}
	    		}else if( item.name.equals(ham)) {
	    			if(item.sellIn<6 && item.quality < maxQuality) {
	    				item.quality += 3;
	    					
	    			}else if(item.sellIn<11 && item.quality < maxQuality) {
	    				item.quality += 2;
	    			}else if(item.quality < maxQuality ) {
	    				item.quality += 1;
	    			}
	    			
	    			if(item.quality>maxQuality) {
	    				item.quality = maxQuality;
	    			}
	    			
	    		}else if(item.quality > minQuality) {
	    			if(item.name.equals(frozenCake)) {
	    				item.quality -= 2;
	    			}else {
	    				item.quality -= 1;
	    			}
	    		}
    		
	    		// Se coloca aqui elpasar el día, porque afecta a la logica de calcular los datos
                item.sellIn = item.sellIn - 1;
            
    	   
	            if (item.sellIn < 0) {
	            		if(item.name.equals(agedBlueCheese) && item.quality<maxQuality) {
	            			item.quality += 1;
	            		}else if (item.name.equals(ham)) {
	            			item.quality = minQuality;
	            		}else if (item.name.equals(frozenCake)) {
	            			if ((item.quality-4) >= minQuality) {
	                			item.quality = item.quality - 4;
	                		}else {
	                			item.quality = minQuality;
	                		}
	            		}else if (item.quality > minQuality) {
	            			item.quality -= 1;
	            		}
	            }
    		}
        }
        
    }
    
    
    public static int incrementQuality() {
    	return 0;
    }
    
    public static int decrementQuality() {
    	return 0;
    }
}