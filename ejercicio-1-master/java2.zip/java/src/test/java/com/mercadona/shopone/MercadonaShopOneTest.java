package com.mercadona.shopone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest {

    @Test
    void itemGenericNotExpired() {
    	
        Item[] items = new Item[] { new Item("Yogurt", 3, 6) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Yogurt", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(5, app.items[0].quality);
      
    }
    
    @Test
    void itemGenericExpired() {
        Item[] items = new Item[] { new Item("Yogurt", 0, 6) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Yogurt", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(4, app.items[0].quality);
      
      
    }
    
    @Test
    void itemGenericExpiredNonZeroQuality() {
        Item[] items = new Item[] { new Item("Yogurt", 0, 0) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Yogurt", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
      
    }
      
    
    void itemBreadNotExpired() {
        Item[] items = new Item[] { new Item("Bread", 6, 2) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(5, app.items[0].sellIn);
        assertEquals(1, app.items[0].quality);
      
    }
    
    void itemBreadExpired() {
        Item[] items = new Item[] { new Item("Bread", -1, 7) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(-2, app.items[0].sellIn);
        assertEquals(5, app.items[0].quality);
      
    }
    
    
    
    void itemAgedBlueCheeseNotExpired() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 5, 8) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(4, app.items[0].sellIn);
        assertEquals(6, app.items[0].quality);
      
    }
    
    void itemAgedBlueCheeseExpired() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 0, 2) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(-2, app.items[0].quality);
      
    }

    
    void itemAgedBlueCheeseNonZeroQuality() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 0, 0) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
      
    }

    
    void itemFrozenCakeNotExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 6, 2) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(5, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
      
    }
    
    void itemFrozenCakeExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", -2, 4) };
        
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-3, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
      
    }
    
    

    
    
    
    
}
