#!/bin/bash

./mvnw clean test
